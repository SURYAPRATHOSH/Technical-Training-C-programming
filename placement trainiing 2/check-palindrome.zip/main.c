#include <stdio.h>
int upsearch(int x){
    int rev=0;
    for(int i=0;x>0;i++){
        rev=rev*10+(x%10);
        x/=10;
    }
    return rev;
}
int downsearch(int y){
    int rev1=0;
    for(int j=0;y>0;j++){
        rev1=rev1*10+(y%10);
        y/=10;
    }
    return rev1;
}

int main()
{
    int num;
    printf("Enter a number : ");
    scanf("%d",&num);
    
    for(int i=0;;i++){
        int m = upsearch(num+i);
        int n = downsearch(num-i);
        if((num+i)==m){
            printf("The nearest palindrome is %d",m);
            break;
        }
        else if((num-i)==n){
            printf("The nearest palindrome is %d",n);
            break;
        }
    }

    return 0;
}