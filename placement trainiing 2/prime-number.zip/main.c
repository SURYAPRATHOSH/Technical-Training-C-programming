#include <stdio.h>

int main()
{
    int num,i;
    printf("Enter the number:");
    scanf("%d",&num);
    for(i=2;i<num-1;i++)
    {
        if(num%i == 0)
        {
            printf("Its Not a Prime");
            break;
        }
    }
    if(i==num-1)
    {
        printf("Its a Prime Number");
    }

    return 0;
}
