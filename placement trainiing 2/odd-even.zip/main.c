/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    printf("Enter a number");
    int num;
    scanf("%d",&num);
    for(int i=1;i<=num;i++){
        if(i&1){
            printf("%d is odd number\n",i);
        }
        else{
            printf("%d is even number\n",i);
        }
    }

    return 0;
}