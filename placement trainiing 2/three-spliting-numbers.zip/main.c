#include <stdio.h>

int main()
{
    int n;
    printf("Enter the number:");
    scanf("%d",&n);
    for(int i=1;i<=n;i+=3)
    {
        
        printf("%d %d %d\n",i,i+1,i+2);
        
    }

    return 0;
}