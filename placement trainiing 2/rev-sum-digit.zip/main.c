#include <stdio.h>
int main()
{
    int a,rev=0,sum=0,sum2=0;
    printf("Enter the number:");
    scanf("%d",&a);
    while(a>0)
    {
        rev =rev*10 + a%10;
        sum2+=(a%10);
        a/=10;
        sum=sum+1;
    }
    printf("%d\n ",rev);
    printf("%d\n",sum);
    printf("%d",sum2);
    return 0;
}
