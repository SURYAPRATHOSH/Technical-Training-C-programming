#include <stdio.h>

void inc(int *x){
    *x+=1;
}
int main()
{
    int a =10;
    inc(&a);
    printf("%d\n",a);

    return 0;
}