#include <stdio.h>

int main()
{
    int num;
    printf("Enter a number : ");
    scanf("%d",&num);
    for(int i=1;i<=num;i++){
        if(i%6==0){
            printf("%d\n",i);
        }
        else{
            printf("%d ",i);
        }
    }
    return 0;
}