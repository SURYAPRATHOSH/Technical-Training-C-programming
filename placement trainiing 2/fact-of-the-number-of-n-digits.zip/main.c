#include <stdio.h>

int main()
{
    int num,sum,total;
    printf("Enter a number : ");
    scanf("%d",&num);
    for(int i=0;num>0;i++){
        sum = num%10;
        int fact=1;
        for(int j=1;j<=sum;j++){
            fact=fact*j;
        }
        printf("Fact of %d is %d\n",sum,fact);
        total+=fact;
        num/=10;
    }
    printf("%d",total);

    return 0;
}