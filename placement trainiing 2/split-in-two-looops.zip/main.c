#include <stdio.h>

int main()
{
    int num,c=1;
    printf("Enter a number : ");
    scanf("%d",&num);
    for(int i=1;i<=num;i++)
    {
        for(int j=1;j<=num;j++)
        {
            printf("%d ",c++);
            
        }
        printf("\n");
    }
    return 0;
}