#include<stdio.h>
int main(){
    int count=1;
    for(int i=5;i>=1;i--){
        for(int j=1;j<=i;j++){
            printf(" %c",'*');
        }
        printf("\n");
    }
}