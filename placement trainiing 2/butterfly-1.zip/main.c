#include <stdio.h>

int main()
{
	int n;
	printf("Enter the number:");
	scanf("%d",&n);
	for(int i=0; i<n; i++)
	{

		for(int j=0; j<i+1; j++)
		{
			printf("*");
		}
		for(int s=0; s<(n-(i+1)); s++)
		{
			printf(" ");
		}
		printf(" ");
		for(int s=0; s<(n-(i+1)); s++)
		{
			printf(" ");
		}
		for(int k=0; k<=i; k++)
		{
			printf("*");
		}

		printf("\n");
	}
	for(int i=1;i<=(n*2)+1;i++)
	{
	    printf("*");
	}printf("\n");

	for(int i=0; i<n; i++)
	{

		for(int j=0; j<(n-(i+1)+1); j++)
		{
			printf("*");
		}
		for(int s=0; s<(i); s++)
		{
			printf(" ");
		}
        printf(" ");
		for(int s=0; s<=i-1; s++)
		{
			printf(" ");
		}
		for(int k=0; k<(n-(i+1)+1); k++)
		{
			printf("*");
		}


		printf("\n");
	}

	return 0;
}