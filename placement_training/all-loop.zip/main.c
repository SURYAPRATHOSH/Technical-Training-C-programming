

#include <stdio.h>

int main()
{
    int num;
    printf("Enter the number:");
    scanf("%d",&num);
     int i;
    {for(int i=1;num>=i;i++)
        {
      
            printf("%d",i);
        
     }
    printf("\n");
    i=1;
    while(i<=num)
    {
        printf("%d",i);
        i++;
        
        
    }
    
    printf("\n");
    i=1;
    
    
    
    do{
        printf("%d",i);
        i++;
        
    }while(i<=num);

    return 0;
}