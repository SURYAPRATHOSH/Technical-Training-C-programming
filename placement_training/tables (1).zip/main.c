#include <stdio.h>

int main()
{
    printf("Enter a number");
    int num;
    int mul;
    scanf("%d",&num);
    for(int i=1;i<=10;i++){
        printf("%d\n",i*num);
    }
    return 0;
}