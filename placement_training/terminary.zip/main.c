
#include <stdio.h>

int main()
{
    int a=10,b=5,c=20;
     ( a>b && a>c )? printf("a is greater"):(b>c)?printf("b"): printf("c");
 
    
    return 0;
}
