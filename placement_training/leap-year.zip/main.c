
#include <stdio.h>

int main()
{
    int yr;
    printf("Enter the  year:");
    scanf("%d",&yr);
    if((yr%4==0 && yr%100!=0) || yr%4==0)
        {
            printf("it is the leap year");
        }
    else
        {
            printf("it is the not leap year");
        }
    return 0;
}
