
#include <stdio.h>

int main()
{
    int a,b,c;
    printf("Enter the side a");
    scanf("%d",&a);
    printf("Enter the side b");
    scanf("%d",&b);
    printf("Enter the side c");
    scanf("%d",&c);
    (a+b)>c?printf("is it"):printf("not");
    return 0;
}
