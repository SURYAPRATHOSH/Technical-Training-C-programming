
#include <stdio.h>

int main()
{
    char ch;
    printf("enter the character:");
    scanf("%c",&ch);
    if(ch>='A' && ch<='Z' || ch>='a' && ch<='z')
    {
        printf("the given character is the letter");
    }
    else if(ch>='0' && ch<='9')
    {
        printf("the given character is number");
        
    }
    else
    {
        printf("---");
    }

    return 0;
}