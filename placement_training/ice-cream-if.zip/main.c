
#include <stdio.h>

int main()
{
    if(!printf("ice"))
    {
        printf("ice");
        
    }
    else
    {
        printf("cream");
    }

    return 0;
}
