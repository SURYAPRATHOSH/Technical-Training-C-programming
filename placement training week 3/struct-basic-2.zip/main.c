#include <stdio.h>
struct Customer
{
    char name[50];
    char phno[10];
    int a;
}cus;

int main()
{
    
    cus.a=10;
    printf("%d",cus.a);
    printf("\nEnter the nuame: ");
    scanf("%s",cus.name);
    printf("%s",cus.name);
    printf("\nEnter your phone nummber:");
    scanf("%s",cus.phno);
    printf("%s",cus.phno);

    return 0;
}
