 #include <stdio.h>

int main()
{
    int n;
    printf("Enter the number of elements : ");
    scanf("%d",&n);
    int arr[n];
    for(int i=0;n>i;i++){
        scanf("%d",&arr[i]);
    }
    for(int i=0;n>i;i++){
        int min = arr[i];
        for(int j=i;n>j;j++){
            if(min>arr[j]){
                min = arr[j];
                break;
            }
        }
        if(min == arr[i]){
            printf("-1 ");}
        else{
        printf("%d ",min);}
    }
    return 0;
}
