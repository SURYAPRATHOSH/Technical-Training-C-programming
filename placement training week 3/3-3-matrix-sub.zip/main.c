#include <stdio.h>

int main()
{
    int n=3;
    int arr[3][3],arr1[3][3],arr2[3][3];
    for(int i=0;n>i;i++)
    {
        for(int j=0;n>j;j++)
        {
            printf("Enter the matrix 1 :");
            scanf("%d",&arr[i][j]);
        }
    }
    for(int i=0;n>i;i++)
    {
        for(int j=0;n>j;j++)
        {
            printf("Enter the matrix 2 :");
            scanf("%d",&arr1[i][j]);
        }
    }
    
    for(int i=0;n>i;i++)
    {
        for(int j=0;n>j;j++)
        {
            arr2[i][j] = arr[i][j] - arr1[i][j];
        }
    }
    
    for(int i=0;n>i;i++){
        for(int j=0;n>j;j++){
            printf("%d ",arr2[i][j]);
        }
        printf("\n");
    }
    
    
    return 0;
}