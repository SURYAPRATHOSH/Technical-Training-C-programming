#include <stdio.h>

int main()
{
	int row,row1,col,col1;
	printf("Enter row and coloum for array1 : ");
	scanf("%d %d",&row,&col);
	printf("Enter row and coloum for array2 : ");
	scanf("%d %d",&row1,&col1);
	int arr[row][col],arr1[row1][col1];
	for(int i=0; row>i; i++)
	{
		for(int j=0; col>j; j++)
		{
			printf("Enter the value for arr[%d][%d] = ",i,j);
			scanf("%d",&arr[i][j]);
		}
	}
	for(int i=0; row1>i; i++)
	{
		for(int j=0; col1>j; j++)
		{
			printf("Enter the value for arr1[%d][%d] = ",i,j);
			scanf("%d",&arr1[i][j]);
		}
	}

	if(row==row1 && col==col1)
	{
		int arr2[row][col];
		for(int i=0; row>i; i++)
		{
			for(int j=0; col>j; j++)
			{
				arr2[i][j]= arr[i][j] + arr1[i][j];
			}
		}
		for(int i=0; row>i; i++)
		{
			for(int j=0; col>j; j++)
			{
				printf("%d ",arr2[i][j]);
			}
			printf("\n");
		}


	}
		
	else if(row<row1)
	{
		row=row1;
	}
	else if(col<col1)
	{
		col=col1;
	}
	int arr2[row][col];
	for(int i=0; row>i; i++)
	{
		for(int j=0; col>j; j++)
		{
			arr2[i][j] = 0;
		}
	}


	for(int i=0; row>i; i++)
	{
		for(int j=0; col>j; j++)
		{
			arr2[i][j]= arr[i][j] + arr1[i][j];
		}
	}
	for(int i=0; row>i; i++)
	{
		for(int j=0; col>j; j++)
		{
			printf("%d ",arr2[i][j]);
		}
		printf("\n");
	}
}