 #include <stdio.h>

int main()
{
    int n;
    printf("Enter the number of elements : ");
    scanf("%d",&n);
    int arr[n];
    for(int i=0;n>i;i++){
        scanf("%d",&arr[i]);
    }
    for(int i=0;n>i;i++){
        int diff = arr[i];
        for(int j=i;n>j;j++){
            if(arr[i]>arr[j]){
                int dif=(arr[i]-arr[j]);
                if(diff>dif){
                    diff=dif;
                }
            }
        }
        if(arr[i]==diff){
            printf("-1 ");
        }
        else{
            printf("%d ",(arr[i]-diff));
        }
    }
}