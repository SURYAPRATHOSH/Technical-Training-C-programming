
#include <stdio.h>

int main()
{
    int num,i,num1;
    printf("num :");
    scanf("%d",&num);
    num1=num;
    for( i=1;i<=num;i++)
    {
        printf("%d  ",i);
        
        printf("%d\n",num1+1);
       // printf("%d\n");
       num1+=1;
       
    }
    return 0;
}
