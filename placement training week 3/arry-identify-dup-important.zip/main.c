#include <stdio.h>

int main()
{
	int n ;
	printf("Enter the size of array : ");
	scanf("%d",&n);
	int arr[n],dup[n];
	for(int i=0; i<n; i++)
	{
		scanf("%d",&arr[i]);
		dup[i] = 0;
	}

	for(int i=0; i<n; i++) 
	{
		if (dup[i])
		continue;
		int val=0;
		for(int j=i+1; j<n; j++)
		{
			if(arr[i]==arr[j])
			{
				dup[j]=1;
				val=1;
			}
		}
		if(val) 
		{
		m	printf("%d ",arr[i]);
			dup[i]=1;
		}
	}
	return 0;
}