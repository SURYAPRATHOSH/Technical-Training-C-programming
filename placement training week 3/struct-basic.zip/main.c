#include <stdio.h>
struct Customer
{
    char name[50];
    char phno[10];
    int a;
};

int main()
{
    struct Customer cus;
    cus.a=10;
    printf("%d",cus.a);
    printf("Enter the nuame: ");
    scanf("%s",cus.name);
    printf("%s",cus.name);
    scanf("%s",cus.phno);
    

    return 0;
}
